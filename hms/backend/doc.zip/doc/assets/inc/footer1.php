<footer class="footer footer-alt">
            2022 - <?php echo date ('Y');?> &copy; Hospital Management System of Sepsis.</a> 
</footer>
